﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MyIntraNet.Models;
using System.Net.Mail;
using System.Configuration;
using System.Data.Linq;
using System.Data.SqlTypes;

namespace MyIntraNet.Controllers
{
    public class RsvpController : Controller
    {
        //
        // GET: /Rsvp/
        
        
        [HttpGet]
        public ViewResult Rsvp()
        {
            return View();
        }
        
        [HttpPost]
        public ActionResult Rsvp(RsvpData rsvpData)
        {
            var rsvpstatus = new RsvpStatus();
            rsvpstatus.setsuccess(0);
            if (ModelState.IsValid)
            {
                if (CheckExistanceInDataBase(rsvpData) == true) { rsvpstatus.setsuccess(1); return RedirectToAction("RsvpAfterSubmit", new {success = rsvpstatus.RsvpSuccess}); }
                if (SendMailRsvp(rsvpData) == false) { rsvpstatus.setsuccess(2); return RedirectToAction("RsvpAfterSubmit", new { success = rsvpstatus.RsvpSuccess }); }
                if (AddRsvpToDataBase(rsvpData) == false) { rsvpstatus.setsuccess(3); return RedirectToAction("RsvpAfterSubmit", new { success = rsvpstatus.RsvpSuccess }); }
                return RedirectToAction("RsvpAfterSubmit", new { success = rsvpstatus.RsvpSuccess });
            }
            else
            {
                return View();
            }
        }

        public ViewResult RsvpAfterSubmit(int success)
        {
            var rsvpstatus = new RsvpStatus();
            rsvpstatus.setsuccess(success);
            return View(rsvpstatus);
        }

        private bool CheckExistanceInDataBase(RsvpData rsvpData)
        {

            var person_exist_context = new DataClasses1DataContext(ConfigurationManager.ConnectionStrings["MyIntranetConnectionString"].ConnectionString);
            int? affinitcount = 0;
            person_exist_context.check_person_existance(rsvpData.Email, rsvpData.Phone, ref affinitcount);
            if (affinitcount > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
            return false;
        }
        private bool AddRsvpToDataBase(RsvpData rsvpData)
        {
            try
            {
                var database_update_context = new DataClasses1DataContext(ConfigurationManager.ConnectionStrings["MyIntranetConnectionString"].ConnectionString);
                int count = 0;
                DateTime current_t = DateTime.Now;
                count = database_update_context.peoples.ToList().Count;
                var new_people = new people { id = count + 1, name = rsvpData.Name, second_name = rsvpData.SecondName, email = rsvpData.Email, phone = rsvpData.Phone };
                database_update_context.peoples.InsertOnSubmit(new_people);
                database_update_context.peoples.Context.SubmitChanges();
                int pid = count + 1;
                count = database_update_context.rsvps.ToList().Count;
                var new_rsvp = new rsvp { id = count + 1, rsvp_time = current_t,person_id = pid, comments = rsvpData.Comments, willattend = rsvpData.WillAttend };
                database_update_context.rsvps.InsertOnSubmit(new_rsvp);
                database_update_context.rsvps.Context.SubmitChanges();
                count = database_update_context.members.ToList().Count;
                var new_member = new member { record_id = count + 1, member_id = pid, group_id = 1 };
                database_update_context.members.InsertOnSubmit(new_member);
                database_update_context.members.Context.SubmitChanges();
                return true;
            }
            catch (Exception e)
            {
                return false;
            }
        }
        private bool SendMailRsvp(RsvpData rsvpData)
        {
            try
            {
                string subject = "Заявка на участие в мероприятии";
                string sendFrom = "aleksander.ep-rza@live.ru";
                string sendTo = "aleksander.ep-rza@live.ru";
                string attend = rsvpData.WillAttend == true ? "Приедет" : "Не приедет";
                string comments = rsvpData.Comments;
                string message = "Имя: " + rsvpData.Name + " Фамилия: " + rsvpData.SecondName + " Электропочта: " + rsvpData.Email + " Труба: " + rsvpData.Phone + " Намерение: " + attend + " Комментарии: " + comments;
                MailMessage Message = new MailMessage();
                Message.Subject = subject;
                Message.Body = message;
                Message.BodyEncoding = System.Text.Encoding.Unicode;
                Message.From = new System.Net.Mail.MailAddress(sendFrom);
                Message.To.Add(new MailAddress(sendTo));
                System.Net.Mail.SmtpClient Smtp = new SmtpClient("smtp.live.com");
                Smtp.Port = 587;
                Smtp.EnableSsl = true;
                Smtp.Credentials = new System.Net.NetworkCredential(sendFrom, "wmaster");
                Smtp.Send(Message);
                return true;
            }
            catch (Exception e)
            {
                return false;
            }
        }
    }
}
