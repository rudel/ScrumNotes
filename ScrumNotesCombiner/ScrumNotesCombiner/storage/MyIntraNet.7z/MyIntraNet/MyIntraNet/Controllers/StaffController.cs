﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MyIntraNet.Controllers
{
    public class StaffController : Controller
    {
        //
        // GET: /Staff/

        public ViewResult Staff()
        {
            return View();
        }

    }
}
