﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MyIntraNet.Controllers
{
    public class DocumentsController : Controller
    {
        //
        // GET: /Documents/

        public ViewResult Documents()
        {
            return View();
        }

    }
}
