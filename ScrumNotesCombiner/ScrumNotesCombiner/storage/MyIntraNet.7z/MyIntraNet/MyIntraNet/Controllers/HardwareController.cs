﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MyIntraNet.Controllers
{
    public class HardwareController : Controller
    {
        //
        // GET: /Hardware/

        public ViewResult Hardware()
        {
            return View();
        }

    }
}
