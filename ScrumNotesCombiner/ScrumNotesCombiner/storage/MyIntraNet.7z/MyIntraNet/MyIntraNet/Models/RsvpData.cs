﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace MyIntraNet.Models
{
    public class RsvpData
    {
        [Required(ErrorMessage = "Не указано имя")]
        public string Name { get; set; }
        [Required(ErrorMessage = "Не указана фамилия")]
        public string SecondName { get; set; }
        [Required(ErrorMessage = "Не введен адрес электропочты")]
        [RegularExpression(".+\\@.+\\..+", ErrorMessage = "Некорректный адрес электронной почты")]
        public string Email { get; set; }
        [Required(ErrorMessage = "Не введен номер телефона")]
        public string Phone { get; set; }

        public string Comments { get; set; }

        [Required(ErrorMessage = "Не указано намерение относительно мероприятия")]
        public bool? WillAttend { get; set; }
    }
}