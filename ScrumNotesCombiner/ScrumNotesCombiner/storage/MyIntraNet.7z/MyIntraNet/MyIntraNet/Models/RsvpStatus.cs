﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MyIntraNet.Models
{
    public class RsvpStatus
    {
        public int RsvpSuccess;
        public void setsuccess(int success)
        {
            RsvpSuccess = success;
        }
    }
}